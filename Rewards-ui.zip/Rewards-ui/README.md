> **⚠️ Important TODO:**  
Add guide-lines in this files!
> 