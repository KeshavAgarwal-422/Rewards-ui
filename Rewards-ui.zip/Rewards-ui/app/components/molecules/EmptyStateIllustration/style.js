import { css } from 'styled-components';

export default css`
  .empty-state-button {
    display: none;
  }
`;
