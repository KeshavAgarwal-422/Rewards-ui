export { default } from './EmptyStateIllustration';
