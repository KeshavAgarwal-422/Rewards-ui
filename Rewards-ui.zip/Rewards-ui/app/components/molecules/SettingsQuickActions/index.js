export { default } from './SettingsQuickActions';
