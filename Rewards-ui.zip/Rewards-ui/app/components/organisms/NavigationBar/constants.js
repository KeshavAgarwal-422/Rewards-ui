export const DEFAULT_MODULE = 'programs';
