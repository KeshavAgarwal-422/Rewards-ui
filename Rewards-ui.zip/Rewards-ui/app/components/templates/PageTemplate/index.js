export { default } from './pageTemplate';
