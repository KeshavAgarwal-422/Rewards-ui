export { default } from './RewardsCatalogSettings';
