import { css } from 'styled-components';

export default css``;
