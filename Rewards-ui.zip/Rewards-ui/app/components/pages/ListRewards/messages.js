/*
 * ListRewards Messages
 *
 * This contains all the text for the ListRewards container.
 */
import { defineMessages } from 'react-intl';

export const scope = 'rewardsCatalog.components.pages.ListRewards';

export default defineMessages({});
