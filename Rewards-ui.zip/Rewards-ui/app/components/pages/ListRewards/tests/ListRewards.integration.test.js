describe('<ListRewards />', () => {
  it('Expect to have integration tests specified', () => {
    expect(true).toEqual(true);
  });
});
