describe('Reducer', () => {
  it('Expect to have reducer tests specified', () => {
    expect(true).toEqual(true);
  });
});
