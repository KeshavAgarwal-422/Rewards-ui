import CustomFieldComponentLazyLoader from './CustomFieldsSettingsComponentLazyLoader';

export { CustomFieldComponentLazyLoader as default };
