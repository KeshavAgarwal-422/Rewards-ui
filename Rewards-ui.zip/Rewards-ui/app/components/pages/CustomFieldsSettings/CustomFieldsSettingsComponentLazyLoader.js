import withLoadable from 'hoc/withLoadable';

export default withLoadable(() => import('./CustomFieldsListing'));
