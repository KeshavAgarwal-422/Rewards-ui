export { default } from './ErrorBoundaryFallback';
