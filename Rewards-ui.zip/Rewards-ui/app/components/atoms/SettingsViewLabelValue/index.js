export { default } from './SettingsViewLabelValue';
