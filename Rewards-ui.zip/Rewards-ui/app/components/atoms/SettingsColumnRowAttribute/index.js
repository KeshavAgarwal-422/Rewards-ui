export { default } from './SettingsColumnRowAttribute';
