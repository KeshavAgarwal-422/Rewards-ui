import { withStyles } from '@capillarytech/vulcan-react-sdk/utils';
export default withStyles;
