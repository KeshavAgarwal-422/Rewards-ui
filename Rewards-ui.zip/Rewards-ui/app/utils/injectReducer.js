import { injectReducer } from '@capillarytech/vulcan-react-sdk/utils';
export default injectReducer;
